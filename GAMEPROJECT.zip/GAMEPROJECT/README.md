## Minesweeper

A simple implementation of Minesweeper game.

I wrote this GUI game as a project for my advanced programming course of University of Guilan.

## Technical Info

Programming Language: Java

User Interface Framework: Swing

Known issue with High-Dpi



